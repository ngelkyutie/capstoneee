<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Announcement</title>
    <link rel="stylesheet" href="../css/patient_announcement.css">
</head>
<body>
<header>
<div class="logo">
            <img src="../Assets/Logo Nav Bar.png" alt="ToothTalk Logo">
        
        <nav>
            <a href="../patient/clinic.php">Clinic</a>
            <a href="#" class="active">Announcement</a>
            <a href="../patient/AboutUs.php">About Us</a>
            <a href="#">Calendar</a>
            <a href="#">Record</a>
       </nav>
       </div>
       <div class="nav-icons">
        <a href="#" class="notification-icon">
            <img src="../Assets/notification.png" alt="Notifications">
            
        </a>
       <div class="nav-avatar">
       <a href="../patient/profile.php"><img src="../Assets/avatar.jpg" alt="User Avatar"></a> 
        </div>
    </header>

    <section class="announcement">
        <div class="announcement-text">
            <h2>ANNOUNCEMENT</h2>
            <img src="../Assets/announcement.jpg" alt="Celebration">
            <p>IT’S A CELEBRATION!<br>We are closed on April 9, 2025. Clinical Operations Resume on April 10, 2025</p>
        </div>
    </section>

</body>
</html>