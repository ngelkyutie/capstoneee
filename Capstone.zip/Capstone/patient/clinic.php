
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dental Clinic</title>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/patient_clinic.css">
</head>
<body>

    <header>
        <div class="logo">
            <img src="../Assets/Logo Nav Bar.png" alt="ToothTalk Logo">
       
        <nav>
            <a href="#" class="active">Clinic</a>
            <a href="../patient/announcement.php">Announcement</a>
            <a href="../patient/AboutUs.php">About Us</a>
            <a href="#">Calendar</a>
            <a href="#">Record</a>
        </nav>
        </div>
        <div class="nav-icons">
        <a href="#" class="notification-icon">
            <img src="../Assets/notification.png" alt="Notifications">
            
        </a>
        <div class="nav-avatar">
           <a href="../patient/profile.php"><img src="../Assets/avatar.jpg" alt="User Avatar"></a> 
        </div>
    </header>

    <section class="hero">
        <h2>Have confidence in your <strong style="color:#219ebc;">SMILE</strong> in no time!</h2>
        <p>If you are seeking for your follow-up care</p>
        <a href="#">Sign in with your patient account</a>
    </section>

    <section class="video-section">
    <video controls autoplay muted loop class="intro-video">
        <source src="../Assets/Dental clinic _ Commercial video.mp4" type="video/mp4">
    </video>
</section>


    <section class="gallery">
    <div class="carousel">
        <button class="carousel-btn prev-btn">❮</button>
        <div class="carousel-track">
            <img src="../Assets/Emax dental crown.jpg" alt="Dental Procedure">
            <img src="../Assets/Flexible denture.jpg" alt="X-ray Consultation">
            <img src="../Assets/Porcelain fused to metal Dental crowns.jpg" alt="Dental Team">
        </div>
        <button class="carousel-btn next-btn">❯</button>
    </div>
</section>

    <section class="services">
        <h2>OUR SERVICES</h2>
        <div class="services-container">
            <div class="service-card">
                <img src="cosmetic.png" alt="Cosmetic Dentistry">
                <p>COSMETIC DENTISTRY</p>
            </div>
            <div class="service-card">
                <img src="laser.png" alt="Laser Dentistry">
                <p>LASER DENTISTRY</p>
            </div>
            <div class="service-card">
                <img src="surgery.png" alt="Oral Surgery">
                <p>ORAL SURGERY</p>
            </div>
            <div class="service-card">
                <img src="periodontics.png" alt="Periodontics">
                <p>PERIODONTICS</p>
            </div>
        </div>
    </section>

    <a href="#" class="back-to-top">↑</a>

    <footer>
      JValera Dental Clinic
    </footer>
</body>
<script src="../js/index.js"></script>
</html>


