<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=<header>
<div class="logo">
            <img src="../Assets/Logo Nav Bar.png" alt="ToothTalk Logo">
        
        <nav>
            <a href="../patient/index.php">Clinic</a>
            <a href="#" class="active">Announcement</a>
            <a href="../patient/AboutUs.php">About Us</a>
            <a href="#">Calendar</a>
            <a href="#" class="active">Record</a>
       </nav>
       </div>
    </header>, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>