<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Account</title>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/patient_profile.css">

</head>
<body>
    <header>
    <div class="logo">
            <img src="../Assets/Logo Nav Bar.png" alt="ToothTalk Logo">
        <nav>
            <a href="../patient/clinic.php">Clinic</a>
            <a href="../patient/announcement.php" >Announcement</a>
            <a href="../patient/AboutUs.php">About Us</a>
            <a href="../patient/calendar.php">Calendar</a>
            <a href="../patient/record.php">Record</a>
       </nav>
       </div>
       <div class="nav-icons">
        <a href="#" class="notification-icon">
            <img src="../Assets/notification.png" alt="Notifications">
            
        </a>
        <div class="nav-avatar">
        <a href="#"><img src="../Assets/avatar.jpg" alt="User Avatar"></a> 
        </div>
    </header>

    <div class="container">
        <h2>PATIENT ACCOUNT</h2>
        <div class="account-section">
            <div class="profile-info">
                <img src="../Assets/avatar.jpg" alt="Patient Photo">
                <h3>Change Profile</h3>
                <p><strong>Josh Andrei Castillo</strong><br>Patient ID: 25-0034</p>
                <div class="profile-buttons">
                    <button class="password">Change Password</button>
                    <a href="../patient/login.php" onclick="return confirmLogout(event);"><button class="logout">Log Out</button></a>
                </div>
            </div>

            <div class="account-details">
                <div class="info-row">
                    <div class="info-block1">
                        <label>First Name</label>
                        <span>Josh Andrei</span>
                    </div>
                    <div class="info-block2">
                        <label>Last Name</label>
                        <span>Castillo</span>
                    </div>
                </div>
                <div class="info-row">
                    <div class="info-block">
                        <label>Birthday</label>
                        <span>05/25/2003</span>
                    </div>
                    <div class="info-block">
                        <label>Age</label>
                        <span>21</span>
                    </div>
                    <div class="info-block">
                        <label>Sex</label>
                        <span>Male</span>
                    </div>
                </div>
                <div class="info-row">
                    <div class="info-block" style="flex-grow:1">
                        <label>Email</label>
                        <span>joshandreicastillo@gmail.com</span>
                    </div>
                </div>
                <div class="info-row">
                    <div class="info-block" style="flex-grow:1">
                        <label>Contact Number</label>
                        <span>09297734219</span>
                    </div>
                </div>

                <button class="edit-btn">Edit</button>
            </div>
        </div>
    </div>
</body>
<script src="../js/patient_logout.js"></script>
</html>

