<?php
require '../connection/db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Prepare and execute query securely
    $sql = "SELECT * FROM patients WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if user exists
    if ($result->num_rows === 1) {
        $patient = $result->fetch_assoc();

        // Verify password against hashed password
        if (password_verify($password, $patient['password'])) {
            // Redirect based on password change status
            if (!$patient['is_password_changed']) {
                header('Location: ../changePass/patient_ChangePass.php?email=' . urlencode($email));
                exit;
            } else {
                // Store session or login flag here if needed
                header('Location: ../patient/clinic.php');
                exit;
            }
        } else {
            echo "<script>alert('Invalid password. Please try again.'); window.history.back();</script>";
        }
    } else {
        echo "<script>alert('Account not found. Please check your email.'); window.history.back();</script>";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=<div class="login-wrapper">
    <link rel="stylesheet" href="../css/patient_login.css">
</head>

<body>
<div class="login-wrapper">
    <div class="login-left">
      <img src="../Assets/Logo Nav Bar.png" alt="Logo" class="logo">
      <h2><strong>LOG IN</strong></h2>

      <form method="POST">
    <label for="username">Email</label>
    <input type="text" name="username" id="username" required>

    <label for="password">Password</label>
    <input type="password" name="password" id="password" required>

    <button type="submit">Login</button>
</form>

      <div class="forgot"><a href="../forgot_pass/forgot-password.php">Forgot Password?</a></div>
    </div>
    <div class="login-right">
        <img src="../Assets/tooth.png" alt="Tooth" class="tooth-image">
    </div>
  </div>
   
</body>
</html>