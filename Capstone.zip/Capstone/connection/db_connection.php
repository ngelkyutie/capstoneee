<?php
$host = "localhost";
$user = "root";
$pass = ""; // change if needed
$db = "ToothTalk"; // change if needed

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
