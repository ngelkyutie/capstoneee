<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="stylesheet" href="../css/aboutUs.css">
</head>
<body>
<header>
<div class="logo">
            <img src="../Assets/Logo Nav Bar.png" alt="ToothTalk Logo">
        
        <nav>
            <a href="../homepage/index.php">Clinic</a>
            <a href="../homepage/announcement.php">Announcement</a>
            <a href="#" class="active">About Us</a>
       </nav>
       </div>
    </header>
    <section class="about">
        <div class="about-content">
            <h2>ABOUT US</h2>
            <h3>JVALERA DENTAL CLINIC</h3>
            <p>We believe in creating smiles that last a lifetime. Located in the heart of Gen. T. De Leon Valenzuela City, our clinic is a place where your comfort and well-being are our top priorities. Our friendly and skilled team takes the time to understand your individual needs and concerns, offering gentle and effective dental care tailored just for you. We’re more than just a dental clinic; we’re your partners in achieving optimal oral health and a confident smile.</p>
            <div class="location">
                <strong>Location</strong><br><br>
                <img src="../Assets/location.png" alt="Map Pin" style="width: 30px; vertical-align: middle;"> 
                Policarpo St. Gen. T. de Leon Valenzuela City, Valenzuela, Philippines<br><br>
                </div>
                <div class="map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3859.4820088192914!2d120.98833607577454!3d14.685312574995764!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397b6a90c119927%3A0x572c4426c6f0a4a8!2sPolicarpio%20%26%20Gen.%20T.%20de%20Leon%2C%20Valenzuela%2C%20Metro%20Manila!5e0!3m2!1sen!2sph!4v1745920063382!5m2!1sen!2sph" 
                 width="600"
                  height="450" 
                  allowfullscreen="" 
                  loading="lazy">
                </iframe>
                </div>
                
        </div>
        <div class="about-img">
            <img src="../Assets/doc.png" alt="Dr. Valera">
        </div>
    </section>
</body>
</html>