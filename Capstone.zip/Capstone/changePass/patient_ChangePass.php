<?php
require '../connection/db_connection.php'; // Include database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $password = trim($_POST['password']);
    $hashed_password = password_hash($password, PASSWORD_BCRYPT); // Hash the password

    // Check if the patient already exists
    $check_sql = "SELECT * FROM patients WHERE email = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param('s', $email);
    $check_stmt->execute();
    $result = $check_stmt->get_result();

    if ($result->num_rows > 0) {
        // Patient already exists
        header('Location: patient_staff_Mngmt.php?error=exists');
        exit;
    } else {
        // Insert new patient into the database
        $sql = "INSERT INTO patients (email, password, first_name, last_name, is_password_changed) VALUES (?, ?, ?, ?, 0)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ssss', $email, $hashed_password, $first_name, $last_name);

        if ($stmt->execute()) {
            // Redirect back to patient_staff_Mngmt.php with a success flag
            header('Location: patient_staff_Mngmt.php?success=1');
            exit;
        } else {
            echo "Error: " . $stmt->error;
        }
    }
}
?>
<?php if (isset($_GET['success']) && $_GET['success'] == 1): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            alert('Patient successfully added!');
        });
    </script>
<?php elseif (isset($_GET['error']) && $_GET['error'] == 'exists'): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            alert('Error: Patient account already exists!');
        });
    </script>
<?php endif; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link rel="stylesheet" href="../css/change_password.css">
</head>
<body>
    <div class="change-password-container">
        <h2>Change Your Password</h2>
        <form id="changePasswordForm" method="POST" action="patient_ChangePass.php">
            <input type="hidden" name="email" value="<?php echo htmlspecialchars($_GET['email']);?>">

            <label for="new_password">New Password:</label>
            <input type="password" name="new_password" id="new_password" required>

            <label for="confirm_password">Confirm Password:</label>
            <input type="password" name="confirm_password" id="confirm_password" required>

            <button type="submit">Change Password</button>
        </form>
    </div>
</body>
</html>