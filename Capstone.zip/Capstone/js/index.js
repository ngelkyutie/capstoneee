document.addEventListener("DOMContentLoaded", function () {
    const track = document.querySelector(".carousel-track");
    const images = Array.from(track.children);
    const prevButton = document.querySelector(".prev-btn");
    const nextButton = document.querySelector(".next-btn");

    let currentIndex = 0;

    // Arrange images side by side
    const setImagePositions = () => {
        images.forEach((img, index) => {
            img.style.left = `${index * 100}%`;
        });
    };

    setImagePositions();

    // Move to the next image
    const moveToImage = (index) => {
        track.style.transform = `translateX(-${index * 100}%)`;
        currentIndex = index;
    };

    nextButton.addEventListener("click", () => {
        if (currentIndex < images.length - 1) {
            moveToImage(currentIndex + 1);
        } else {
            moveToImage(0); // Loop back to the first image
        }
    });

    prevButton.addEventListener("click", () => {
        if (currentIndex > 0) {
            moveToImage(currentIndex - 1);
        } else {
            moveToImage(images.length - 1); // Loop back to the last image
        }
    });

    // Auto-slide functionality
    setInterval(() => {
        if (currentIndex < images.length - 1) {
            moveToImage(currentIndex + 1);
        } else {
            moveToImage(0); // Loop back to the first image
        }
    }, 5000); // Change image every 5 seconds
});