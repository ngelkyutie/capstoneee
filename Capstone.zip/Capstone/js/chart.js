const sexCtx = document.getElementById('sexChart').getContext('2d');
new Chart(sexCtx, {
    type: 'pie',
    data: {
        labels: ['Male', 'Female'],
        datasets: [{
            data: [28.6, 71.4],
            backgroundColor: ['#4fc3f7', '#81c784']
        }]
    },
    options: {
        plugins: { legend: { position: 'bottom' } }
    }
});

// Age Chart
const ageCtx = document.getElementById('ageChart').getContext('2d');
new Chart(ageCtx, {
    type: 'pie',
    data: {
        labels: ['Pediatric', 'Adult', 'Geriatric'],
        datasets: [{
            data: [8.3, 75, 16.7],
            backgroundColor: ['#ffb74d', '#64b5f6', '#9575cd']
        }]
    },
    options: {
        plugins: { legend: { position: 'bottom' } }
    }
});

// Feedback Bar Chart
const feedbackCtx = document.getElementById('feedbackChart').getContext('2d');
new Chart(feedbackCtx, {
    type: 'bar',
    data: {
        labels: ['5 Stars', '4 Stars', '3 Stars', '2 Stars', '1 Star'],
        datasets: [{
            label: 'Service Feedback',
            data: [10, 9, 5, 2, 2],
            backgroundColor: '#0097a7'
        }]
    },
    options: {
        scales: {
            y: { beginAtZero: true }
        }
    }
});