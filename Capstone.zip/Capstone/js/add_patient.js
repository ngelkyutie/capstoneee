document.addEventListener('DOMContentLoaded', function () {
    const modal = document.getElementById('addPatientModal');
    const openModalButton = document.getElementById('openModalButton');
    const closeModalButton = document.getElementById('closeModalButton');
    const addPatientForm = document.getElementById('addPatientForm');

    // Open the modal
    openModalButton.addEventListener('click', function () {
        modal.style.display = 'flex';
    });

    // Close the modal
    closeModalButton.addEventListener('click', function () {
        modal.style.display = 'none';
    });

    // Close the modal when clicking outside the modal content
    window.addEventListener('click', function (event) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });

    // Handle form submission
    addPatientForm.addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent default form submission

        // Collect form data
        const formData = new FormData(addPatientForm);

        // Send data to the server using Fetch API
        fetch('add_patient.php', {
            method: 'POST',
            body: formData
        })
            .then(response => response.text())
            .then(data => {
                // Close the modal
                modal.style.display = 'none';

                // Show success message
                alert('Patient successfully added!');

                // Optionally, reload the page to update the patient list
                location.reload();
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while adding the patient.');
            });
    });
    // Show the success prompt
function showSuccessPrompt(message) {
    const successPrompt = document.getElementById('successPrompt');
    successPrompt.textContent = message; // Set the message
    successPrompt.style.display = 'block'; // Show the prompt

    // Hide the prompt after 4 seconds
    setTimeout(() => {
        successPrompt.style.display = 'none';
    }, 4000);
}

// Check for success flag in the URL
document.addEventListener('DOMContentLoaded', function () {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('success') && urlParams.get('success') === '1') {
        showSuccessPrompt('Patient successfully added!');
    }
});
});