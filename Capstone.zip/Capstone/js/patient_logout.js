// Function to confirm logout action
function confirmLogout(event) {
    // Prevent the default behavior of the link
    event.preventDefault();

    // Create overlay
    const overlay = document.createElement('div');
    overlay.className = 'logout-overlay';
    document.body.appendChild(overlay);

    // Create confirmation box
    const confirmationBox = document.createElement('div');
    confirmationBox.className = 'logout-confirmation';
    confirmationBox.innerHTML = `
        <h3>Are you sure you want to log out?</h3>
        <div class="buttons">
            <button class="confirm-btn">Yes</button>
            <button class="cancel-btn">No</button>
        </div>
    `;
    document.body.appendChild(confirmationBox);

    // Add event listeners for buttons
    confirmationBox.querySelector('.confirm-btn').addEventListener('click', () => {
        window.location.href = '../patient/login.php'; 
    });

    confirmationBox.querySelector('.cancel-btn').addEventListener('click', () => {
        document.body.removeChild(confirmationBox);
        document.body.removeChild(overlay);
    });
}