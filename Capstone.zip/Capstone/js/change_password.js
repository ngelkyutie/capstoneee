document.getElementById('changePasswordForm').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent form submission

    const newPassword = document.getElementById('new_password').value;
    const confirmPassword = document.getElementById('confirm_password').value;

    // Check if passwords match
    if (newPassword !== confirmPassword) {
        alert('Passwords do not match. Please try again.');
        return;
    }

    // Show confirmation prompt
    const confirmation = confirm('Are you sure you want to change your password?');
    if (confirmation) {
        this.submit(); // Submit the form if confirmed
    }
});