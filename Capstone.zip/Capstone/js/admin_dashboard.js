 // Render the Sex pie chart
 const sexCtx = document.getElementById('sexChart').getContext('2d');
 new Chart(sexCtx, {
   type: 'pie',
   data: {
     labels: ['Male', 'Female'],
     datasets: [{
       data: [28.6, 71.4], // Example data
       backgroundColor: ['#41b8d5', '#6ce5e8'],
       borderColor: ['#2a8ca1', '#4db8c1'],
       borderWidth: 2
     }]
   },
   options: {
     responsive: true,
     plugins: {
       legend: {
         position: 'bottom',
         labels: {
           font: {
             size: 14
           }
         }
       },
       tooltip: {
         callbacks: {
           label: function(context) {
             return `${context.label}: ${context.raw}%`;
           }
         }
       }
     }
   }
 });
 

// Render the Age pie chart
const ageCtx = document.getElementById('ageChart').getContext('2d');
new Chart(ageCtx, {
  type: 'pie',
  data: {
    labels: ['Pediatric', 'Adult', 'Geriatric'],
    datasets: [{
      data: [8.3, 75, 16.7], // Example data
      backgroundColor: ['#6ce5e8', '#41b8d5', '#2d8bba'],
      borderColor: ['#4db8c1', '#2a8ca1', '#1f6e8a'],
      borderWidth: 2
    }]
  },
  options: {
    responsive: true,
    plugins: {
      legend: {
        position: 'bottom',
        labels: {
          font: {
            size: 14
          }
        }
      },
      tooltip: {
        callbacks: {
          label: function(context) {
            return `${context.label}: ${context.raw}%`;
          }
        }
      }
    }
  }
});

// Render the Service Feedback bar chart
const feedbackCtx = document.getElementById('feedbackChart').getContext('2d');
new Chart(feedbackCtx, {
  type: 'bar',
  data: {
    labels: ['5 Stars', '4 Stars', '3 Stars', '2 Stars', '1 Star'],
    datasets: [{
      label: 'Number of Ratings',
      data: [10, 8, 2, 1, 1], // Example data
      backgroundColor: ['#2d8bba', '#41b8d5', '#6ce5e8', '#a3e4f1', '#d9f7fc'],
      borderColor: ['#1f6e8a', '#2a8ca1', '#4db8c1', '#7fd0e0', '#bcecf5'],
      borderWidth: 2
    }]
  },
  options: {
    responsive: true,
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        callbacks: {
          label: function(context) {
            return `${context.label}: ${context.raw}`;
          }
        }
      }
    },
    scales: {
      x: {
        title: {
          display: true,
          text: 'Rating Levels',
          font: {
            size: 14
          }
        }
      },
      y: {
        beginAtZero: true,
        title: {
          display: true,
          text: 'Number of Ratings',
          font: {
            size: 14
          }
        }
      }
    }
  }
});

// Function to confirm logout action
function confirmLogout(event) {
    // Prevent the default behavior of the link
    event.preventDefault();

    // Create overlay
    const overlay = document.createElement('div');
    overlay.className = 'logout-overlay';
    document.body.appendChild(overlay);

    // Create confirmation box
    const confirmationBox = document.createElement('div');
    confirmationBox.className = 'logout-confirmation';
    confirmationBox.innerHTML = `
        <h3>Are you sure you want to log out?</h3>
        <div class="buttons">
            <button class="confirm-btn">Yes</button>
            <button class="cancel-btn">No</button>
        </div>
    `;
    document.body.appendChild(confirmationBox);

    // Add event listeners for buttons
    confirmationBox.querySelector('.confirm-btn').addEventListener('click', () => {
        window.location.href = '../admin/admin_login.php'; // Redirect to admin_login page
    });

    confirmationBox.querySelector('.cancel-btn').addEventListener('click', () => {
        document.body.removeChild(confirmationBox);
        document.body.removeChild(overlay);
    });
}